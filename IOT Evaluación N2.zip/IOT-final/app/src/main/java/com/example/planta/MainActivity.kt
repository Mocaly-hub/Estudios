
package com.example.planta

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Colores inspirados en la naturaleza
val Verde = Color(0xFF527D50)
val VerdeClaro = Color(0xFFE8F0E5)
val Tierra = Color(0xFF8D7358)
val Fondo = Color(0xFFF7F8F2)
val Blanco = Color.White

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val dbHelper = DatabaseHelper(this)

        setContent {
            MaterialTheme {
                var ingresoCorrecto by remember {
                    mutableStateOf(false)
                }

                if (ingresoCorrecto) {
                    PantallaIndicadores()
                } else {
                    PantallaLogin {
                        ingresoCorrecto = true
                    }
                }
            }
        }
    }
}

@Composable
fun PantallaLogin(onLoginExitoso: () -> Unit) {
    val context = LocalContext.current
    val dbHelper = remember { DatabaseHelper(context) }

    var usuario by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Fondo)
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "MI PLANTA",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = Verde
        )

        Text(
            text = "Monitoreo de cultivo",
            color = Tierra,
            modifier = Modifier.padding(bottom = 32.dp)
        )

        OutlinedTextField(
            value = usuario,
            onValueChange = { usuario = it },
            label = { Text("Usuario") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            singleLine = true
        )

        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Contraseña") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 24.dp),
            singleLine = true
        )

        Button(
            onClick = {
                if (usuario.isBlank() || password.isBlank()) {
                    Toast.makeText(
                        context,
                        "Completa todos los campos",
                        Toast.LENGTH_SHORT
                    ).show()
                } else if (dbHelper.validarUsuario(usuario, password)) {
                    onLoginExitoso()
                } else {
                    Toast.makeText(
                        context,
                        "Usuario o contraseña incorrectos",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Verde
            )
        ) {
            Text("INGRESAR", fontSize = 16.sp)
        }
    }
}

@Composable
fun PantallaIndicadores() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Fondo)
            .padding(20.dp)
    ) {
        Text(
            text = "Panel de mi planta",
            fontSize = 25.sp,
            fontWeight = FontWeight.Bold,
            color = Verde
        )

        Text(
            text = "Indicadores del cultivo",
            color = Tierra,
            modifier = Modifier.padding(top = 4.dp, bottom = 20.dp)
        )

        // Tabla de indicadores
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp),
            colors = CardDefaults.cardColors(
                containerColor = Blanco
            )
        ) {
            Column(modifier = Modifier.padding(12.dp)) {

                // Encabezados
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(VerdeClaro)
                        .padding(vertical = 12.dp, horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Indicador",
                        modifier = Modifier.weight(1.3f),
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = Verde
                    )
                    Text(
                        "Valor",
                        modifier = Modifier.weight(0.8f),
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = Verde
                    )
                    Text(
                        "Estado",
                        modifier = Modifier.weight(1f),
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = Verde
                    )
                }

                FilaIndicador("pH del suelo", "6.5", "Normal")
                HorizontalDivider(color = VerdeClaro)
                FilaIndicador("Temperatura", "24 °C", "Normal")
                HorizontalDivider(color = VerdeClaro)
                FilaIndicador("Humedad", "45 %", "Adecuada")
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "Resumen",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = Verde
        )

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 10.dp),
            colors = CardDefaults.cardColors(
                containerColor = VerdeClaro
            ),
            shape = RoundedCornerShape(8.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "La planta presenta condiciones estables.",
                    fontWeight = FontWeight.Medium,
                    color = Verde
                )

                Text(
                    text = "Los valores mostrados son de ejemplo y no provienen de sensores reales.",
                    fontSize = 13.sp,
                    color = Tierra,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        }
    }
}

@Composable
fun FilaIndicador(
    indicador: String,
    valor: String,
    estado: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = indicador,
            modifier = Modifier.weight(1.3f),
            fontSize = 12.sp
        )

        Text(
            text = valor,
            modifier = Modifier.weight(0.8f),
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = Verde
        )

        Text(
            text = estado,
            modifier = Modifier.weight(1f),
            fontSize = 11.sp,
            color = Verde
        )
    }
}
