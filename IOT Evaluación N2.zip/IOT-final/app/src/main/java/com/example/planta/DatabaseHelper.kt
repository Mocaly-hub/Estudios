package com.example.planta

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, "AppLocal.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase?) {
        // Crear tabla de usuarios en el celular/emulador
        val createTable = "CREATE TABLE usuarios (id INTEGER PRIMARY KEY AUTOINCREMENT, usuario TEXT, password TEXT)"
        db?.execSQL(createTable)

        // Insertar usuario de prueba automáticamente al instalar la app
        val values = ContentValues().apply {
            put("usuario", "admin")
            put("password", "1234")
        }
        db?.insert("usuarios", null, values)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE IF EXISTS usuarios")
        onCreate(db)
    }

    // Función para verificar credenciales de inicio de sesión
    fun validarUsuario(user: String, pass: String): Boolean {
        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT * FROM usuarios WHERE usuario = ? AND password = ?",
            arrayOf(user, pass),
        )
        val existe = cursor.count > 0
        cursor.close()
        return existe
    }
}